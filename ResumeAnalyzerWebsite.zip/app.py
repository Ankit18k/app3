from flask import Flask, render_template, request
import PyPDF2
import os

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html', resume_text=None)

@app.route('/upload', methods=['POST'])
def upload():
    if 'resume' not in request.files:
        return "No file uploaded", 400
    file = request.files['resume']
    if file.filename.endswith('.pdf'):
        reader = PyPDF2.PdfReader(file)
        text = ""
        for page in reader.pages:
            text += page.extract_text()
        return render_template('index.html', resume_text=text)
    else:
        return "Please upload a PDF file", 400

if __name__ == '__main__':
    app.run(debug=True)
